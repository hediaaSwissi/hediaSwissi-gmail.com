function run(id) {
    id.style.top = Math.round(Math.random() * 250) - 100 + 'px';
    id.style.left = Math.round(Math.random() * 250) - 200 + 'px';
}
function chan(){
    document.getElementById("t").value= "you'll be my girl \u2665";
}